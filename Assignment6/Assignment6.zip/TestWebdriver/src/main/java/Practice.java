import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Scanner;
public class Practice {
  static WebDriver driver;
    public static void main(String[] args) {
		
		System.out.println("Please Enter the browser :");
		Scanner sc= new Scanner(System.in);
		String value = sc.nextLine();
		
		if(value.equalsIgnoreCase("Chrome"))
		{
			ChromeOptions handlingSSL = new ChromeOptions();
			handlingSSL.setAcceptInsecureCerts(true);
			driver = new ChromeDriver(handlingSSL);
			
		}
		else if (value.equalsIgnoreCase("Firefox")) {

			FirefoxOptions handlingSSL = new FirefoxOptions();
			handlingSSL.setAcceptInsecureCerts(true);
		   driver= new FirefoxDriver(handlingSSL);
		}
		
		driver.manage().window().maximize();
		
		//get info at login page
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("admin");
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("Admin095");
		WebElement login = driver.findElement(By.name("login"));
		login.click();
		
		//adding customer
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");

		WebElement usertype=driver.findElement(By.id("user_type_id"));
		Select dropdown = new Select(usertype);
		dropdown.selectByIndex(6);
		
		WebElement SalesAgent = driver.findElement(By.id("sales_agent_id"));
		Select dropdown1  = new Select(SalesAgent);
		dropdown1.selectByIndex(3);
		
		WebElement firstname = driver.findElement(By.id("firstname"));
		firstname.sendKeys("Himani");
		WebElement lastname = driver.findElement(By.id("lastname"));
		lastname.sendKeys("Lalkiya");
		WebElement email = driver.findElement(By.name("email"));
		email.sendKeys("auto@test.com");
		WebElement secondemail = driver.findElement(By.id("secondary_emails"));
		secondemail.sendKeys("check@test.com");
		WebElement Password = driver.findElement(By.name("password"));
		Password.sendKeys("Admin@123");
		
		WebElement ForcePwd = driver.findElement(By.cssSelector("input#force_password_reset"));
		ForcePwd.click();
		
		WebElement Phoneno = driver.findElement(By.name("phone_number"));
		Phoneno.sendKeys("3214950606");
		WebElement Companyname = driver.findElement(By.id("companyname"));
		Companyname.sendKeys("Radix");
		WebElement usergrp = driver.findElement(By.id("user_discount_group_id"));
		Select dropdown2 = new Select(usergrp);
		dropdown1.selectByIndex(2);
		//WebElement state = driver.findElement(By.className("btn dropdown-toggle bs-placeholder btn-light"));
		//Select dropdown3 = new Select(state);
		//select.selectByVisibletext("Alaska");
	   // WebElement Save = driver.findElement(By.id("btn-action-save"));
		//Save.click();
		WebElement SaveBack= driver.findElement(By.id("btn-action-saveback"));
		SaveBack.click();
		
    } 
}

  