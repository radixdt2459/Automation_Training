package Program;

import java.util.ArrayList;
import java.util.Scanner;

public class Program2 {
public static void main(String[] args) {

	int n,i;
	int[] array = new int[5];
	Scanner sc= new Scanner(System.in); 
	
	//for product price
	System.out.print("Enter the number of Product price you want to Store: ");
	n = sc.nextInt();
	System.out.println("Enter 5 Product Price: ");
		for(i=0;i<n;i++) {
			array[i]= sc.nextInt();
		 }
		 
	System.out.println("The Price of Product are:");
		 for(i=0;i<n;i++) {
		 	if(array[i]==400) {
		 	break;
		 }
	System.out.println(array[i]);
}
	//for quantity
	System.out.print("Enter the number of quantity you want to Store: ");
	n = sc.nextInt();
	System.out.println("Enter 5 Quantities: ");
		for(i=0;i<n;i++) {
		array[i]= sc.nextInt();
	}
	 
	System.out.println("The QTY of Product are:");
	 	for(i=0;i<n;i++) {
		if(array[i]>=1000) {
 			continue;
 		}
	 System.out.println(array[i]);
	 	}
	//for size
	System.out.print("Enter the number of size you want to Store: ");
		n = sc.nextInt();
	System.out.println("Enter 5 sizes: ");
		for(i=0;i<n;i++) {
		array[i]= sc.nextInt();
	}
		 
	System.out.println("The size of Product are:");
		 for(i=0;i<n;i++) {
	System.out.println(array[i]);
		}
    }
}
		







