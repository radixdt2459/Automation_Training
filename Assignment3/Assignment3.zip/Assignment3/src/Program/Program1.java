package Program;
import java.util.Scanner;

public class Program1 {
	
	public static void main(String [] args) {
		int number;
		int sum;
		int evenNumber=0;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number:");
		 number = sc.nextInt();
		 
		for(sum =1;sum <=number;sum ++) {
			if(sum %2==0)
			{
				evenNumber =evenNumber + sum;
			}
		}
		 System.out.println("Sum of Even numbers between 1 to " +  number  + " is equals to >> " +  evenNumber);
	}
}
