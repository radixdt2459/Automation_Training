package Program;
import java.util.ArrayList;
import java.util.Scanner;
public class Program3 {

	public static void main(String[] args) {
		 ArrayList<String> FirstArray = new ArrayList<String>();
		 ArrayList<String> SecondArray = new ArrayList<String>();
		    Scanner sc= new Scanner(System.in);
		 
		 	System.out.println("Enter string for First array list: ");
		 		
		 	for(int i=0;i<2;i++){
		 		
			 	String FirstArr= sc.next();
			 	FirstArray.add(FirstArr);
		 	} 	
		 	System.out.println("Enter string for Second array list: ");
		 	
		 	for(int i=0;i<2;i++){
			 	String SecondArr= sc.next();
		    	SecondArray.add(SecondArr);
		    }
		 	System.out.println("First array" + FirstArray);
		 	System.out.println("Second array" + SecondArray);
		
		    {
		        FirstArray.addAll(SecondArray);
				System.out.println("Updated string after adding the both strings>> " + FirstArray);
		    }	
	 }
}

