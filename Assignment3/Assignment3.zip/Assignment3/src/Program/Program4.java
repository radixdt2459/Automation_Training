package Program;
import java.util.Scanner;
public class Program4 {

	public static void main(String[] args) {
		 Scanner sc= new Scanner(System.in);
		 
		 System.out.print("Enter your full name: ");
		  char firstname= sc.nextLine().charAt(0);
		  System.out.print("Enter your full name: ");
		  char middlename= sc.nextLine().charAt(0);
		  System.out.print("Enter your full name: ");
		  String lastname= sc.nextLine();
		  
		  System.out.println("Name after abberviation will be: " + firstname + "." + middlename + "." + lastname);
	}
}
