package Program1;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrudTestMethod {
	CustomerCrud ct = new CustomerCrud();
	String Propertiesfile, Filename, Sheetname;

	@BeforeTest
	public void setup() {
		ct.setup();
		System.out.println("Setup done");
	}

	@BeforeMethod
	@Parameters({ "Propertiesfile", "Filename", "Sheetname" })
	public void Configuration(String Propertiesfile, String Filename, String Sheetname) throws IOException {

		this.Propertiesfile = Propertiesfile;
		this.Filename = Filename;
		this.Sheetname = Sheetname;
	}

	@Test
	public void LoginUser() throws IOException, InterruptedException {
		ct.LoginUser(Propertiesfile, Filename, Sheetname);
		System.out.println("User loggedIn");
	}

	@Test
	public void AddUser() throws IOException, InterruptedException {
		ct.AddUser(Propertiesfile, Filename, Sheetname);
		System.out.println("User added");
	}

	@Test
	public void EditUser() throws IOException, InterruptedException {
		ct.EditUser(Propertiesfile, Filename, Sheetname);
	}

	@Test
	public void DeleteUser() throws IOException {
		ct.DeleteUser(Propertiesfile, Filename, Sheetname);
		System.out.println("User deleted");
	}

	@AfterMethod
	public void Crud() {
		System.out.println("aftermethod");
	}

	@AfterTest
	public void BrowserClose() {
		ct.BrowserClose();
		System.out.println("Browser closed");
	}
}
