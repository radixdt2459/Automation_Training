package Program1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebControl {

	public void handleTextfields(WebDriver driver, String Xpath, String Values) {
		WebElement textfield = driver.findElement(By.xpath(Xpath));
		textfield.clear();
		textfield.sendKeys(Values);
	}

	public void handleDropdown(WebDriver driver, String Xpath, int Values) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		Select dropdown = new Select(element);
		dropdown.selectByIndex(Values);
	}

	public void handleCheckBox(WebDriver driver, String Xpath) {
		WebElement checkbox = driver.findElement(By.xpath(Xpath));
		if (!checkbox.isSelected()) {
			checkbox.click();
		}
	}
	public void handleClick(WebDriver driver, String Xpath) {
		WebElement Clicks = driver.findElement(By.xpath(Xpath));
		Clicks.click();
	}
}
