package Program1;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	private static final int RowNum = 0;
	static FileInputStream fin;
	 static XSSFWorkbook wb;
	 static XSSFSheet s1;
	 static XSSFRow r1;
	private static Object getCell;
	public static String Cellvalue;
	private static XSSFSheet s2;
		
	public static int getRowCount(String Sheetname ,String Filename) throws IOException {
			fin =new FileInputStream(Filename);
			wb= new XSSFWorkbook(fin);
			s1 = wb.getSheet(Sheetname);
			r1 = s1.getRow(0);
			int rowCount = s1.getLastRowNum();
		    return rowCount;
	}

	public static String getCell(int rowvalue , String Colname) {
		int RowSize = s1.getLastRowNum();
		int CellSize = s1.getRow(0).getLastCellNum();
		
		 String Cellvalue = null;
		for(int cell=0; cell < CellSize; cell++) {
			XSSFCell c1 =s1.getRow(0).getCell(cell); //header cell
		 
		   if(c1 != null && c1.toString().equals(Colname)) {
			 Cellvalue = s1.getRow(rowvalue).getCell(cell).toString(); //get data cell
	         break; }
	 }
		return Cellvalue;
	}
	}

