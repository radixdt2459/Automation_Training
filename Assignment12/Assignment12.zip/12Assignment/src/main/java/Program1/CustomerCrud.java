package Program1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import Program1.WebControl;
import Program1.ReadExcel;

public class CustomerCrud {
	public WebDriver driver;
	WebControl weblocate = new WebControl();

	String Loginurl = "https://ops-qa.radixdev79.com/admin/";

	public String getProp(String key, String Propertiesfile) throws IOException {
		File src = new File(Propertiesfile);
		FileInputStream fin = new FileInputStream(src);
		Properties obj = new Properties();
		obj.load(fin);
		return obj.getProperty(key);
	}

	public void setup() {
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		driver = new ChromeDriver(handlingSSL);
		driver.get(Loginurl);
		driver.manage().window().maximize();
	}

	public void LoginUser(String Propertiesfile, String Filename, String Sheetname)
			throws IOException, InterruptedException {
		weblocate.handleTextfields(driver, getProp("Username", Propertiesfile), "admin");
		weblocate.handleTextfields(driver, getProp("Password1", Propertiesfile), "Admin095");
		weblocate.handleClick(driver, getProp("Login", Propertiesfile));
	}

	public void AddUser(String Propertiesfile, String Filename, String Sheetname) throws IOException {
		int rowCount = ReadExcel.getRowCount(Sheetname, Filename);
		for (int i = 1; i <= rowCount; i++) {
			driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");

			weblocate.handleTextfields(driver, getProp("Firstname", Propertiesfile), ReadExcel.getCell(i, "Firstname"));
			weblocate.handleTextfields(driver, getProp("Lastname", Propertiesfile), ReadExcel.getCell(i, "Lastname"));
			weblocate.handleTextfields(driver, getProp("Email", Propertiesfile), ReadExcel.getCell(i, "Email"));
			weblocate.handleTextfields(driver, getProp("Password", Propertiesfile), ReadExcel.getCell(i, "Password"));
			weblocate.handleTextfields(driver, getProp("Phoneno", Propertiesfile), ReadExcel.getCell(i, "Phoneno"));
			WebElement SaveBack = driver.findElement(By.xpath(getProp("SaveBack", Propertiesfile)));
			SaveBack.click();
		}
	}

	public void EditUser(String Propertiesfile, String Filename, String Sheetname)
			throws InterruptedException, IOException {

		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_listing.php");
		Thread.sleep(2000);
		weblocate.handleClick(driver, getProp("Action", Propertiesfile));
		weblocate.handleClick(driver, getProp("Edit", Propertiesfile));

		int Editrow = ReadExcel.getRowCount(Sheetname, Filename);
		for (int i = 1; i <= Editrow; i++) {
			weblocate.handleTextfields(driver, getProp("Firstname", Propertiesfile), ReadExcel.getCell(i, "Firstname"));
			weblocate.handleClick(driver, getProp("SaveBack", Propertiesfile));
		}
	}

	public void DeleteUser(String Propertiesfile, String Filename, String Sheetname) throws IOException {
		weblocate.handleClick(driver, getProp("Action", Propertiesfile));
		weblocate.handleClick(driver, getProp("Delete", Propertiesfile));
		//weblocate.handleClick(driver, getProp("Accept", Propertiesfile));
	}

	public void BrowserClose() {
		driver.close();

	}

}
