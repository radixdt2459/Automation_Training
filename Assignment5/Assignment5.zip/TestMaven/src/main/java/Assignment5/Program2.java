package Assignment5;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Program2 {

	public static void main(String[] args) throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook ();
		XSSFSheet s1 = wb.createSheet("TestCase Info");
		Object [][] testcase = { {"SRno", "Title", "Expected Result"},
					                 {"1","Add module", "Module should be added"},
					                 {"2","Edit module", "Module should be updated"},
					                 {"3","Delete module", "Module should be deleted"}
					       };
			int rows = testcase.length;
			int cols = testcase[0].length;
			
			for (int r= 0; r<rows;r++) {
				XSSFRow row = s1.createRow(r);
				
				for (int c= 0; c<cols;c++) {
					XSSFCell cell = row.createCell(c);
					Object value = testcase[r][c];
					
					if(value instanceof String)
						cell.setCellValue((String)value);
					if(value instanceof Integer)
						cell.setCellValue((Integer)value);
					if(value instanceof Boolean)
						cell.setCellValue((Boolean)value);
	                 }
				 }
			
			FileOutputStream fout = new FileOutputStream("TC_details.xlsx");
			wb.write(fout);
			wb.close();
			System.out.println("File written successfully...");
    }
}

