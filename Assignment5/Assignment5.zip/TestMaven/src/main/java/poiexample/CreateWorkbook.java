package poiexample;

import java.io.FileOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CreateWorkbook {

	public static void main(String[] args) {
		XSSFWorkbook wb = new XSSFWorkbook();
		try {
			FileOutputStream fout = new FileOutputStream("C:\\Users\\himani.lalkiya\\eclipse-workspace\\TestMaven\\Testfile.xlsx");
			wb.write(fout);
			
		} catch (Exception e) {
			System.out.println("File not created");
		}
	}
}
