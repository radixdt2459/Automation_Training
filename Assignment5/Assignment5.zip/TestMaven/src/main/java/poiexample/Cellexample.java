package poiexample;

import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Cellexample {

	public static void main(String[] args) {
		XSSFWorkbook wb = new XSSFWorkbook ();
		try {
			FileOutputStream fout = new FileOutputStream("Test1.xlsx");
			XSSFSheet s1 = wb.createSheet("Newsheet");
			XSSFRow r = s1.createRow(2);
			XSSFCell c = r.createCell(2);
			c.setCellValue("Hii 2");
			wb.write(fout);
			System.out.println("Cell created..");
		} catch (Exception e) {
			System.out.println("Cell not created..");
		}
	}
}
