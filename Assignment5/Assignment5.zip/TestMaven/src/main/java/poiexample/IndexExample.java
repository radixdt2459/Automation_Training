package poiexample;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class IndexExample {

	public static void main(String[] args) throws IOException {
		
		FileInputStream fin = new FileInputStream ("TC_details.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fin);
		XSSFSheet s1 = wb.getSheetAt(0);
		XSSFRow r = s1.getRow(2); 
		XSSFCell c =r.getCell(1);
		System.out.println(s1.getRow(2).getCell(1));
	}
}
