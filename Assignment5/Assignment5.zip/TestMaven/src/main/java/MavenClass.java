import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MavenClass {
public static void main(String[] args) throws FileNotFoundException, IOException {
	XSSFWorkbook wb = new XSSFWorkbook();
	try {
		FileOutputStream fout = new FileOutputStream("C:\\Users\\himani.lalkiya\\eclipse-workspace\\TestMaven\\Test1.xlsx");
		wb.write(fout);
		
	} catch (Exception e) {
		System.out.println("File not created");
	}
  }
}
