import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Program1 {

	public static void main(String[] args) throws IOException {
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		ChromeDriver driver = new ChromeDriver(handlingSSL);
       
		File src = new File("src/test/resources/Data.properties");
		FileInputStream fin= new FileInputStream(src);
		Properties obj = new Properties();
		obj.load(fin);
		
		driver.manage().window().maximize();
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
		
		WebElement Username= driver.findElement(By.xpath(obj.getProperty("Username")));
		Username.sendKeys("admin");
		WebElement Password1= driver.findElement(By.xpath(obj.getProperty("Password1")));
	    Password1.sendKeys("Admin095");
		WebElement Login= driver.findElement(By.xpath(obj.getProperty("Login")));
        Login.click();
        
        int rowCount=Exceldetails2.getRowCount(0);
		for(int i=1;i<=rowCount;i++) {
			
	    driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");	
	        
		// WebElement Add = driver.findElement(By.xpath(obj.getProperty("Add")));
		//.click();
		WebElement Firstname = driver.findElement(By.xpath(obj.getProperty("Firstname")));
		String firstnameValue=Exceldetails2.getCell(i,"Firstname");
		if (firstnameValue != null) {
	        Firstname.sendKeys(firstnameValue);
	    } else {
	        System.out.println("Firstname is null for row " + i);
	    }
	     
		WebElement Lastname = driver.findElement(By.xpath(obj.getProperty("Lastname")));
		String LastnameValue=Exceldetails2.getCell(i,"Lastname");
		if (LastnameValue != null) {
	        Lastname.sendKeys(LastnameValue);
	    } else {
	        System.out.println("Lastname is null for row " + i);
	    }
	
		WebElement Email = driver.findElement(By.xpath(obj.getProperty("Email")));
		String EmailValue=Exceldetails2.getCell(i,"Email");
		if (EmailValue != null) {
	       Email.sendKeys(EmailValue);
	    } else {
	        System.out.println("Phoneno is null for row " + i);
	    }
	
        WebElement Password = driver.findElement(By.xpath(obj.getProperty("Password")));
        String PasswordValue=Exceldetails2.getCell(i,"Password");
		if (PasswordValue != null) {
	        Password.sendKeys(PasswordValue);
	    } else {
	        System.out.println("Phoneno is null for row " + i);
	    }
	
	    WebElement Phoneno = driver.findElement(By.xpath(obj.getProperty("Phoneno")));
	    String PhonenoValue=Exceldetails2.getCell(i,"Phoneno");
		if (PhonenoValue != null) {
	        Phoneno.sendKeys(PhonenoValue);
	    } else {
	        System.out.println("Phoneno is null for row " + i);
	    }
		WebElement Save = driver.findElement(By.xpath(obj.getProperty("Save")));
	     Save.sendKeys("Save");
	    //driver.quit();
	 }
   }  
 }

