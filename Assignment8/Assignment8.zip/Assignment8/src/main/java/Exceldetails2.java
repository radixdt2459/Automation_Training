import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Exceldetails2{
	static FileInputStream fin;
	 static XSSFWorkbook wb;
	 static XSSFSheet s1;
	 static XSSFRow r1;
	private static Object getCell;
	public static String Cellvalue;
	
public static int getRowCount(int RowIndex) throws IOException {
		fin =new FileInputStream("Data.xlsx");
		wb= new XSSFWorkbook(fin);
		s1 = wb.getSheetAt(0);
		r1 = s1.getRow(0);
		int rowCount = s1.getLastRowNum();
	    return rowCount;
}

public static String getCell(int rowvalue , String Colname) {
	int RowSize = s1.getLastRowNum();
	int CellSize = s1.getRow(0).getLastCellNum();
	
	 for(int cell=0; cell < CellSize; cell++) {
		XSSFCell c1 =s1.getRow(0).getCell(cell); //header cell
	 
	   if(c1 != null && c1.toString().equals(Colname)) {
		 Cellvalue = s1.getRow(rowvalue).getCell(cell).toString(); //get data cell
         break; }
 }
	return Cellvalue;
  }
}
  