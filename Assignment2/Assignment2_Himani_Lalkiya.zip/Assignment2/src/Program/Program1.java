package Program;

public class Program1{
	
	public void sum(){
		int a=50;
		int b=5;
		int sum = a+b;
		System.out.println("The addition of two numbers will be : " + sum);
		
	}
	 public void subtract() {
	    	float a=50f;
	 		float b=5f;
	    	float subtract = a-b;	
	     System.out.println("The substraction of two numbers will be : " + subtract);
	}
	  
	 public void mulitply() {
	    	int a=50;
	 		double b=5.45;
	    	double mulitply = a*b;	
	     System.out.println("The multiplication of two numbers will be : " + mulitply);
	}
	 
	 public void division() {
	    	int a=50;
	 		int b=5;
	    	int division = a/b;	
	     System.out.println("The divison of two numbers will be : " + division);
	 }
	 
	    public static void main(String[] args){
			Program1 operation= new Program1();
			operation.sum();
			operation.subtract();
			operation.mulitply();
			operation.division();
	    }
}