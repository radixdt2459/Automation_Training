package Program;
import java.util.Scanner;

public class Program4 {
    
    
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
			
			System.out.println("Please Enter the year of Job started :");
			int jobYear =sc.nextInt();
			
			System.out.println("Please Enter year of Birth :");
			int birthYear =sc.nextInt();
			
			int currentYear = 2024;
			
		    //calculate current date and candidate total experience
			int age = currentYear - birthYear;
			int Experience= currentYear - jobYear;
			
			System.out.println("Candidate's Age: " + age + " years");
	        System.out.println("Total Experience: " + Experience + " years");
			
		if (Experience<22 && age<=40) {
				System.out.println("Yes!! You are eligible for the Job");
		}	
			else {
				System.out.println("Sorry...You are not eligible for the Job");
		}	
       
	}
}
