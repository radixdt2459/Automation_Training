package Program;

import java.util.Scanner;

public class Program2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter first string :" );
		String s1 = sc.nextLine();
		
				 
		System.out.println("Please Enter second string :");
		String s2 = sc.nextLine();
	
		// join using '+'
		System.out.println("Result after join two Strings >> " + s1 + s2);
		
		/* join using 'concat' function
		System.out.println("Result after join two Strings >> " + s1.concat(s2));*/
		
		//compare string
		System.out.println("Result after join and compare two Strings >> " + (s1.equals(s2)));
	}

}