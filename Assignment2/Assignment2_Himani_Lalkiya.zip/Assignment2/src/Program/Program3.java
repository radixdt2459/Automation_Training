package Program;

import java.util.*;
import java.util.Scanner;

public class Program3{
   public static void main(String[] args){
	   
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter 5 first name :");
		String firstName1 =sc.nextLine();
		String firstName2 =sc.nextLine();
		String firstName3 =sc.nextLine();
		String firstName4 =sc.nextLine();
		String firstName5 =sc.nextLine();
		
		System.out.println("Please Enter 5 last name :");
		String lastName1 =sc.nextLine();
		String lastName2 =sc.nextLine();
		String lastName3 =sc.nextLine();
		String lastName4 =sc.nextLine();
		String lastName5 =sc.nextLine();
		

		System.out.printf("Combination of first names and last names>>" + firstName1.concat(lastName1));
        System.out.println("Combination of first names and last names>>" + firstName2.concat(lastName2));
		System.out.println("Combination of first names and last names>>" + firstName3.concat(lastName3));
		System.out.println("Combination of first names and last names>>" + firstName4.concat(lastName4));
		System.out.println("Combination of first names and last names>>" + firstName5.concat(lastName5));
		
		String[] array= {firstName1, firstName2, firstName3, firstName4, firstName5};
	    
		Arrays.sort(array);
		System.out.println("First Names in Alphabetical order : " +  Arrays.toString(array));
  }
}
      /*using for loop
       * List<String> firstNames = new ArrayList<>();
	        for (int i = 0; i < 5; i++) {
	        	System.out.print("First name " + (i + 1) + ": ");
	            firstNames.add(sc.nextLine());
	        }
	        
	        List<String> lastNames = new ArrayList<>();
	        System.out.println("Enter 5 last names:");
	        for (int i = 0; i < 5; i++) {
	            System.out.print("Last name " + (i + 1) + ": ");
	            lastNames.add(scanner.nextLine());
	        
	         List<String> fullNames = new ArrayList<>();
	            for (int i = 0; i < 5; i++) {
	              fullNames.add(firstNames.get(i) + " " + lastNames.get(i));
      */
        
