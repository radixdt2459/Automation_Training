import java.util.concurrent.TimeUnit;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Program1 {
	public static void takeScreenshot (String Filename, WebDriver driver) throws IOException {
		TakesScreenshot scrscreen = (TakesScreenshot)driver;
		File scr= scrscreen.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scr, new File(Filename));
 }
public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
	    ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		ChromeDriver driver = new ChromeDriver(handlingSSL);
		driver.manage().window().maximize() ;
		//get info at login page
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
		Thread.sleep(2000);
		takeScreenshot("Login.png" , driver);
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
		WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
		username.sendKeys("admin");
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys("Admin095");
		WebElement login = driver.findElement(By.xpath("//button[@name='login']"));
		login.click();
		takeScreenshot("Dashboard.png" , driver);
		
		//user listing
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_listing.php");
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);  
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		takeScreenshot("UserList.png" , driver); // call screenshot function
	    //adding customer
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");
		WebElement usertype=driver.findElement(By.xpath("//select[@id='user_type_id']"));
		Select dropdown = new Select(usertype);
		dropdown.selectByIndex(6);
		WebElement SalesAgent = driver.findElement(By.xpath("//select[@id='sales_agent_id']"));
		Select dropdown1  = new Select(SalesAgent);
		dropdown1.selectByIndex(3);		
		WebElement firstname = driver.findElement(By.xpath("//input[@id='firstname']"));
		firstname.sendKeys("Himani");
		WebElement lastname = driver.findElement(By.xpath("//input[@name='lastname']"));
		lastname.sendKeys("Lalkiya");
		WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
		email.sendKeys("himani.lalkiya@radixweb.com");
		WebElement Password = driver.findElement(By.xpath("//input[@name='password']"));
		Password.sendKeys("Admin@123");
		WebElement ForcePwd = driver.findElement(By.xpath("//input[@name='force_password_reset']"));
		ForcePwd.click();
		WebElement Phoneno = driver.findElement(By.xpath("//input[@id='phone_number']"));
		Phoneno.sendKeys("3214950606");
		WebElement Companyname = driver.findElement(By.xpath("//input[@id='companyname']"));
		Companyname.sendKeys("Radix");
		WebElement usergrp = driver.findElement(By.xpath("//select[@id='user_discount_group_id']"));
		Select dropdown2 = new Select(usergrp);
		dropdown1.selectByIndex(2);
		WebElement Gender = driver.findElement(By.xpath("//input[@id='radio_Female']"));
		Gender.click();	
	    WebElement SaveBack = driver.findElement(By.xpath("//button[@id='btn-action-saveback']"));
	    SaveBack.click();
		takeScreenshot("AddCustomer.png" , driver);
		
		//Edit Customer
		WebElement Action = driver.findElement(By.xpath("(//div[contains(@class,'col-btn-actions')])[1]"));
		Action.click();
		WebElement Edit = driver.findElement(By.xpath("(//i[contains(@class,'far fa-pencil')])[1]"));      
		Edit.click();
		WebElement EditPhone = driver.findElement(By.xpath("//input[@name='phone_number']"));
		EditPhone.clear();
		EditPhone.sendKeys("3091297865");
	    WebElement AllowTax = driver.findElement(By.xpath("//input[@name='tax_exempt']"));
	    AllowTax.click();
	    takeScreenshot("EditCustomer.png" , driver);
	    WebElement SaveBack1 = driver.findElement(By.xpath("//button[@id='btn-action-saveback']"));
	    SaveBack1.click();
	    
	   //Delete customer
	    WebElement DeleteCustomer = driver.findElement(By.xpath("(//i[contains(@class,'fa-trash')])[1]"));      
	    DeleteCustomer.click();
	    WebElement Accept = driver.findElement(By.xpath("//button[@class='btn btn-primary bootbox-accept']"));      
	    Accept.click();
	    takeScreenshot("DeleteCustomer.png" , driver);}
}
