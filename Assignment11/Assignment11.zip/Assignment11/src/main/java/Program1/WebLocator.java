package Program1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebLocator {
	public void handleTextfields(WebDriver driver, String Xpath, String Values) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		element.clear();
		element.sendKeys(Values);
	}

	public void handleDropdown(WebDriver driver, String Xpath, int Values) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		Select dropdown = new Select(element);
		dropdown.selectByIndex(Values);
	}

	public void handleRadiobutton(WebDriver driver, String Xpath) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		element.click();

	}

	public void handleCheckBox(WebDriver driver, String Xpath) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		if (!element.isSelected()) {
			element.click();
		}
	}

	public void handleClick(WebDriver driver, String Xpath) {
		WebElement element = driver.findElement(By.xpath(Xpath));
		element.click();
	}
}
