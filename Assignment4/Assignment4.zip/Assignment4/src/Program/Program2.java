package Program;
import java.util.*;
class Bank{
	int Interest() {
		return 0;}
}
class SBI extends Bank {
	float Interest(float amount, float time, float rate) {
	float RateofInt;
	RateofInt= (amount * time * rate)/100;
	return RateofInt;}
}
class ICICI extends Bank{
	float Interest(float amount, float time, float rate) {
		float RateofInt;
		RateofInt= (amount * time * rate)/100;
		return RateofInt;}
}
class AXIS extends Bank{
	float Interest(float amount, float time, float rate) {
		float RateofInt;
		RateofInt= (amount * time * rate)/100;
		return RateofInt;}
}
public class Program2 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the amount of loan: ");
		float amount = sc.nextFloat();
		System.out.println("Please enter the time interval: ");
		float time= sc.nextFloat();
		
		SBI sbi= new SBI ();
		float rate=7;
		ICICI ici = new ICICI();
		float rate1=8;
		AXIS axis = new AXIS();
		float rate2=9;
		
		System.out.println("SBI bank rate of Interest is: "+ sbi.Interest(amount, time, rate));
		System.out.println("ICICI bank rate of Interest is: "+ ici.Interest(amount, time, rate1));
		System.out.println("AXIS bank rate of Interest is: "+ axis.Interest(amount, time, rate2));
  }
}