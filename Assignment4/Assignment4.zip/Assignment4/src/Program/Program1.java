package Program;

abstract class Marks{
	abstract float getPercentage();
}
class StudentA extends Marks{
	private int subject1, subject2, subject3;

	StudentA(int subject1, int subject2, int subject3){
	  this.subject1 = subject1;
      this.subject2 = subject2;
      this.subject3 = subject3;
}
	@Override
	float getPercentage() {
		float totalMarks = subject1 + subject2 + subject3;
		return (totalMarks / 300) * 100;
    }
}
class StudentB extends Marks{
	private int subject1, subject2, subject3, subject4;
	
    StudentB(int subject1, int subject2, int subject3, int subject4){
	  this.subject1 = subject1;
      this.subject2 = subject2;
      this.subject3 = subject3;
      this.subject4 = subject4;
}
	@Override
	float getPercentage() {
		float totalMarks = subject1 + subject2 + subject3 + subject4;
        return (totalMarks / 400) * 100;
    }
}
public class Program1 {
	public static void main(String[] args) {
	 StudentA sA= new StudentA(55,89,60);
	 StudentB sB= new StudentB(85,80,97,83);
	 System.out.println("Percentage of Student A: " + sA.getPercentage() + "%");
	 System.out.println("Percentage of Student B: " + sB.getPercentage() + "%");
    }
}
