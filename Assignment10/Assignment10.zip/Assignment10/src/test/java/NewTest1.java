import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void Print() {
	  System.out.println("Printing hello....");
   }
  @Test
  public void Write() {
	  System.out.println("Writing hello....");
   }
}
