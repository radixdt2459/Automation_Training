package Program1;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
public class Crud { 
	private CrudTest crudtest;
	CrudTest ct = new CrudTest(); 
	 @BeforeTest
  public void setup() {
	  ct.setup();
	  System.out.println("Setup done");
   }
    @Test
  public void LoginUser() throws IOException, InterruptedException {
	  ct.LoginUser();
	  System.out.println("User loggedIn");
  }
  @Test
  public void AddUser() throws IOException {
	  ct.AddUser();
	  System.out.println("User added");
  }
  @Test
  public void EditUser() throws IOException {
	  ct.EditUser();
	  System.out.println("User details updated");
  }
  @Test
  public void DeleteUser() throws InterruptedException, IOException {
	  ct.DeleteUser();
	  System.out.println("User deleted successfully");
  }
  @AfterTest
  public void BrowserClose() {
	  ct.BrowserClose(); 
	  System.out.println("Browser closed");
  }
 }
