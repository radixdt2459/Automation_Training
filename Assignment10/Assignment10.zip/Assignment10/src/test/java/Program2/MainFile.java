package Program2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import Program1.WebLocator;

public class MainFile {
	public WebDriver driver;
	WebLocator weblocate = new WebLocator();
	String Loginurl="https://ops-qa.radixdev79.com/admin/";
	
	public String getProp(String key) throws IOException {
		File src = new File("src/test/resources/Crud.properties");
		FileInputStream fin= new FileInputStream(src);
		Properties obj = new Properties();
		obj.load(fin);
		return obj.getProperty(key);
	}
	
		public void BrowseLoad() throws IOException {
			ChromeOptions handlingSSL = new ChromeOptions();
			handlingSSL.setAcceptInsecureCerts(true);
			driver = new ChromeDriver(handlingSSL);
			driver.get(Loginurl);
	}

	public void Login() throws IOException {
		weblocate.handleTextfields(driver, getProp("Username"), "admin");
		weblocate.handleTextfields(driver, getProp("Password"), "Admin095");
		weblocate.handleClick(driver, getProp("Login"));
	}

	public void Add() throws IOException {
		int rowCount = Exceldata.getRowCount("Sheet1");
		for (int i = 1; i <= rowCount; i++) {
			driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");

			weblocate.handleTextfields(driver, getProp("Firstname"), Exceldata.getCell(i, "Firstname"));
			weblocate.handleTextfields(driver, getProp("Lastname"), Exceldata.getCell(i, "Lastname"));
			weblocate.handleTextfields(driver, getProp("Email"), Exceldata.getCell(i, "Email"));
			weblocate.handleTextfields(driver, getProp("Password"), Exceldata.getCell(i, "Password"));
			weblocate.handleTextfields(driver, getProp("Password"), Exceldata.getCell(i, "Phoneno"));
			weblocate.handleClick(driver, getProp("SaveBack"));
		}
	}

	public void Edit() throws IOException {

		WebElement Action = driver.findElement(By.xpath(getProp("Action")));
		Action.click();
		WebElement Edit = driver.findElement(By.xpath(getProp("Edit")));
		Edit.click();

		int rowCount = Exceldata.getRowCount("Sheet2");
		for (int i = 1; i <= rowCount; i++) {
			weblocate.handleTextfields(driver, getProp("Firstname"), Exceldata.getCell(i, "Firstname"));
			weblocate.handleClick(driver, getProp("SaveBack"));
		}
	}

	public void BrowserClose() {
		driver.quit();
	}
}
	   
