package Program2;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Program2.MainFile;
public class ReadExcel {
//	private MainFile file;
    MainFile main = new MainFile(); 
    
	 @BeforeTest
  public void BrowseLoad() throws IOException {
	  main.BrowseLoad();
	  System.out.println("Setup done");
   }
    @Test
    public void LoginUser() throws IOException, InterruptedException {
  	  main.Login();
  	  System.out.println("User loggedIn");
    }
    @Test
    public void AddUser() throws IOException {
  	  main.Add();
  	  System.out.println("User added");
    }
    @Test
    public void EditUser() throws IOException {
  	  main.Edit();
  	  System.out.println("User details updated");
    }
  @AfterTest
  public void BrowserClose() {
	  main.BrowserClose(); 
	  System.out.println("Browser closed");
  }
}
