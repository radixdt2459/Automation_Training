package Program1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CrudTest {
	public WebDriver driver;
	WebLocator weblocate = new WebLocator();

	String Loginurl = "https://ops-qa.radixdev79.com/admin/";

	public String getProp(String key) throws IOException {
		File src = new File("src/test/resources/Crud.properties");
		FileInputStream fin = new FileInputStream(src);
		Properties obj = new Properties();
		obj.load(fin);
		return obj.getProperty(key);
	}

	public void setup() {
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		driver = new ChromeDriver(handlingSSL);
		driver.get(Loginurl);
		driver.manage().window().maximize();
	}

	public void LoginUser() throws IOException, InterruptedException {
		weblocate.handleTextfields(driver, getProp("Username"), "admin");
		weblocate.handleTextfields(driver, getProp("Password"), "Admin095");
		weblocate.handleClick(driver, getProp("Login"));
	}

	public void AddUser() throws IOException {
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");
		weblocate.handleDropdown(driver, getProp("Usertype"), 6);
		weblocate.handleDropdown(driver, getProp("SalesAgent"), 3);
		weblocate.handleTextfields(driver, getProp("Firstname"), "Himani");
		weblocate.handleTextfields(driver, getProp("Lastname"), "Lalkiya");
		weblocate.handleTextfields(driver, getProp("Email"), "himani.lalkiya@radixweb.com");
		weblocate.handleTextfields(driver, getProp("Password"), "Admin!123");
		weblocate.handleTextfields(driver, getProp("PhoneEdit"), "9584334908");
		weblocate.handleTextfields(driver, getProp("CompanyName"), "Radixweb");
		weblocate.handleDropdown(driver, getProp("Usergrp"), 4);
		weblocate.handleRadiobutton(driver, getProp("Gender"));
		weblocate.handleCheckBox(driver, getProp("Checkbox"));
		weblocate.handleClick(driver, getProp("Notify"));
		weblocate.handleClick(driver, getProp("Allowtax"));
		weblocate.handleClick(driver, getProp("SaveBack"));
	}

	public void EditUser() throws IOException {
		WebElement Action = driver.findElement(By.xpath(getProp("Action")));
		Action.click();
		WebElement Edit = driver.findElement(By.xpath(getProp("Edit")));
		Edit.click();
		weblocate.handleTextfields(driver, getProp("PhoneEdit"), "9584334999");
		weblocate.handleClick(driver, getProp("SaveBack"));
	}

	public void DeleteUser() throws InterruptedException, IOException {
		WebElement Delete = driver.findElement(By.xpath(getProp("Delete")));
		Delete.click();
		weblocate.handleClick(driver, getProp("Accept"));
	}

	public void BrowserClose() {
		driver.quit();
	}
}