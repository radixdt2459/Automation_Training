import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class Practice7 {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		ChromeDriver driver = new ChromeDriver(handlingSSL);
		driver.manage().window().maximize() ;
       
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
        WebElement username= driver.findElement(By.xpath("//input[@id= \"username\"]"));
        username.sendKeys("admin");
        
        WebElement password =driver.findElement(By.xpath("//input[@id= \"password\"]"));
        password.sendKeys("Admin095");
        
        WebElement login = driver.findElement(By.xpath("//button[@name='login']"));
        login.click();
        
        driver.getCurrentUrl();
        
        driver.navigate().to("https://ops-qa.radixdev79.com/admin/template_manager.php");
        
        //Add template
        WebElement Addtemp = driver.findElement(By.xpath("//div[@class='action_area float-right']//child::a[text()=' Add']"));
        Addtemp.click();
        Thread.sleep(3000);
      //search dropdown
        WebElement Usertype = driver.findElement(By.xpath("//button[@class='btn dropdown-toggle btn-white bs-placeholder']"));
        Usertype.click();
        
        WebElement search = driver.findElement(By.xpath("//div[contains(@class,'store-filter')]//input"));
        search.sendKeys("Default Store");
        
        java.util.List<WebElement> usertype=driver.findElements(By.xpath("//li[@class='optgroup-1']"));
        Usertype.sendKeys("Default Store");
        	for(WebElement listitem :usertype) {
        		if(listitem.getText().equals("store")) {
        			listitem.click();
        			break;}
        	}
      
        WebElement Productype= driver.findElement(By.xpath("//div[@class='col-md-2 col-form-label']//following::select[@id='predefined_product_type']"));
        Select dropdown = new Select(Productype);
		dropdown.selectByIndex(1);
		
        WebElement Title = driver.findElement(By.xpath("//input[@id='templatename1']"));
        Title.sendKeys("AutoTemplate");
        
        WebElement TemplateType = driver.findElement(By.xpath("//input[@id='ttype_2']"));
        TemplateType.click();        
        
        WebElement Status = driver.findElement(By.xpath(""));
		Status.click();
   }

}
