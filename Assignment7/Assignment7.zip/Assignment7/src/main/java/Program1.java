import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Scanner;
public class Program1{
  static WebDriver driver;
    public static void main(String[] args) {
    	ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		ChromeDriver driver = new ChromeDriver(handlingSSL);
		driver.manage().window().maximize() ;
		
		//get info at login page
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/");
		WebElement username = driver.findElement(By.xpath("//input[@id='username']"));
		username.sendKeys("admin");
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys("Admin095");
		WebElement login = driver.findElement(By.xpath("//button[@name='login']"));
		login.click();
		
		//adding customer
		driver.navigate().to("https://ops-qa.radixdev79.com/admin/user_action.php");

		WebElement usertype=driver.findElement(By.xpath("//select[@id='user_type_id']"));
		Select dropdown = new Select(usertype);
		dropdown.selectByIndex(6);
		
		WebElement SalesAgent = driver.findElement(By.xpath("//select[@id='sales_agent_id']"));
		Select dropdown1  = new Select(SalesAgent);
		dropdown1.selectByIndex(3);
		
		WebElement firstname = driver.findElement(By.xpath("//input[@id='firstname']"));
		firstname.sendKeys("Himani");
		WebElement lastname = driver.findElement(By.xpath("//input[@name='lastname']"));
		lastname.sendKeys("Lalkiya");
		WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
		email.sendKeys("auto@test.com");
		WebElement secondemail = driver.findElement(By.xpath("//input[@name='secondary_emails']"));
		secondemail.sendKeys("check@test.com");
		WebElement Password = driver.findElement(By.xpath("//input[@name='password']"));
		Password.sendKeys("Admin@123");
		
		WebElement ForcePwd = driver.findElement(By.xpath("//input[@name='force_password_reset']"));
		ForcePwd.click();
		
		WebElement Phoneno = driver.findElement(By.xpath("//input[@id='phone_number']"));
		Phoneno.sendKeys("3214950606");
		WebElement Companyname = driver.findElement(By.xpath("//input[@id='companyname']"));
		Companyname.sendKeys("Radix");
		WebElement usergrp = driver.findElement(By.xpath("//select[@id='user_discount_group_id']"));
		Select dropdown2 = new Select(usergrp);
		dropdown1.selectByIndex(2);
		
		WebElement Gender = driver.findElement(By.xpath("//input[@id='radio_Female']"));
		Gender.click();
		
		WebElement Agreement = driver.findElement(By.xpath("//input[@value='Not Agreed'] "));
		
		//boolean cb=Agreement.isSelected();
		
		if(!Agreement.isSelected()){
			System.out.println("Already Selected");
			Agreement.click();
		}	
	   // WebElement Save = driver.findElement(By.id("btn-action-save"));
		//Save.click();
		WebElement SaveBack= driver.findElement(By.id("btn-action-saveback"));
		SaveBack.click();
		
    } 
}

  
